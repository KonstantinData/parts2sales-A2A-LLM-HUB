# 🧪 Draft Prompts

Experimental and work-in-progress prompts. These are untested and excluded from CI/CD by default.