# 📊 Evaluation Results

This directory stores output logs and evaluation results from prompt benchmarking runs.
Each task has its own folder for storing scored runs and audit logs.