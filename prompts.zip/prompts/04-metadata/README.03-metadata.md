# 📑 Prompt Metadata

This directory contains metadata files for each prompt, such as version, schema, changelog, or model binding details.