# utils/openai_client.py

"""
OpenAI Client Wrapper

Version: 2.0.0
Author: Konstantin Milonas with Agentic AI Copilot support

Purpose:
Centralized access to OpenAI chat completions.
Injectable in all agents via constructor.
"""

import os
from dotenv import load_dotenv
from openai import OpenAI

# Load .env file variables
load_dotenv(override=True)


class OpenAIClient:
    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("Missing OPENAI_API_KEY environment variable.")
        self.client = OpenAI(api_key=api_key)

    def chat(self, prompt: str, model: str = "gpt-4", temperature: float = 0.2) -> str:
        response = self.client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content.strip()
