"""Lightweight test agents used by the unit test suite."""

from .prompt_quality_agent import PromptQualityAgent
